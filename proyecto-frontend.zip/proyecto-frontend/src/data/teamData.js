const team = [
  {
    id: 1,
    name: "Aybar Reyes, Jesus Andre",
    photo: "/images/Jesus.jpg",
    role: "Desarrollador"
  },
  {
    id: 2,
    name: "Huaman Chavez, Alonso Arturo",
    photo: "/images/Alonso.jpg",
    role: "Frontend"
  },
  {
    id: 3,
    name: "Cabrejos Salazar, Andre Fernando",
    photo: "/images/Andre.jpg",
    role: "Desarrollador"
  },
  {
    id: 4,
    name: "Crisostomo Quispe, Gabriel Alejandro",
    photo: "/images/Gabriel.jpg",
    role: "Desarrollador"
  },
  {
    id: 5,
    name: "Seminario Cerna, Jean Franco",
    photo: "/images/Jean.jpg",
    role: "Diseñador"
  },
  {
    id: 6,
    name: "Huachaca Espinal, Aaron Alejandro",
    photo: "/images/Aaron.jpg",
    role: "Diseñador"
  }
];

export default team;
