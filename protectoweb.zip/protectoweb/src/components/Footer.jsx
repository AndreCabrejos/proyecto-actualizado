export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Streamoria. Todos los derechos reservados.</p>
    </footer>
  );
}
